///Programa em Java que mostra os números pares e ímpares 
/////Escreva um aplicativo em Java que recebe inteiro e mostra os números pares e ímpares (separados), de 1 até esse inteiro


import java.util.Scanner;

public class ParesEImpares {
public static void main(String[] args) {

Scanner scanner = new Scanner(System.in);
System.out.print("Digite um número inteiro positivo: ");
int numeroMaximo = scanner.nextInt();
int i = 1;

System.out.print("Números Impares de 1 até " + numeroMaximo + ": ");
while (i <= numeroMaximo) {
if (i % 2 != 0) {
System.out.print(i + " ");
}
i++;
}
System.out.println();
i = 1;

System.out.print("Números Pares de 1 até " + numeroMaximo + ": ");
while (i <= numeroMaximo) {
if (i % 2 == 0) {
System.out.print(i + " ");
}
i++;
}
System.out.println();
scanner.close();
}
}