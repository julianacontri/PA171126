import java.util.Scanner;

public class Desconto {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o valor total da compra (R$): ");
        double valorCompra = scanner.nextDouble();

        if (valorCompra > 500.00) {
            System.out.println("Parabéns! Você tem direito a um desconto.");
        } else {
            System.out.println("Compras até R$ 500,00 não possuem direito a desconto.");
        }

        scanner.close();
    }
}
