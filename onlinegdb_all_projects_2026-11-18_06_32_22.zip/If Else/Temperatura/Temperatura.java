import java.util.Scanner;

public class Temperatura {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite a Temperatura atual em °C: ");
        double Temperatura = scanner.nextDouble();

        if (Temperatura > 30) {
            System.out.println("Temperatura está quente");
            
        } else {
        System.out.println(" Temperatura está amena" );
        }

        scanner.close();
    }
}
