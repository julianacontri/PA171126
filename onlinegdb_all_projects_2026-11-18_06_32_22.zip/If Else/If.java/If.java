public class Main {
  public static void main(String[] args) {
    int x = 24;
    int y = 22;
    if (x == y) 
    {
      System.out.println("x is equal to y");
    }
    
    if (x > y)
	{
    	System.out.println("X é maior que Y");
     
  	}
    
    if (x < y)
    {
    	System.out.println("X é menor que Y");
    }

}
}