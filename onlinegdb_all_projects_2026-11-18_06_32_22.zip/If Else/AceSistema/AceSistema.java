import java.util.Scanner;

public class AceSistema {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int senhaCorreta = 1234;

        System.out.print("Digite a senha numérica: ");
        int senhaDigitada = scanner.nextInt();
        
        if (senhaDigitada == senhaCorreta) {
            System.out.println("Acesso liberado. Bem-vindo!");
        } else {
            System.out.println("Acesso negado. Senha incorreta.");
        }

        scanner.close();
    }
}