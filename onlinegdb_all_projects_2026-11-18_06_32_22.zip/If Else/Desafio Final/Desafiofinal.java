////Desenvolva um sistema que receba nome, idade e duas notas de um aluno. 
///O programa deve informar se o aluno é maior de idade e se foi aprovado ou reprovado
import java.util.Scanner;

    public static void main(String[] args) 
    {
    String nome;
    int idade;
    Double nota1, nota2,média;
    int resposta=1;
    
    
    while (resposta == 1)
    {
    Scanner teclado = new Scanner (System.in);
    System.out.println("Qual é o seu nome: ");
    nome= teclado.next();
    
     System.out.println("Qual é a sua idade: ");
     idade= teclado.nextInt();

        if (idade >= 18) 
        {
            System.out.println("Você é maior de idade");
        }    
        else if (idade<18) 
        {
        System.out.println(" Você é menor de idade" );
        }
        
          System.out.println("Insira nota1: ");
        nota1= teclado.nextDouble();
        
          System.out.println("Insira nota2: ");
        nota2= teclado.nextDouble();
        
        média=(nota1+nota2)/2;
        
        if (média >=5)
        {
            System.out.println("sua média é : "+média);
            System.out.println("aprovado: ");
        }
        else if (média <5) 
        {
        System.out.println("sua média é : "+média);
        System.out.println(" reprovado" );
        }
        {
      System.out.println("Deseja executar o programa novamente? Digite 1- Sim e 2 - Não");
       resposta=teclado.nextInt();
        }
    }
    }


    
