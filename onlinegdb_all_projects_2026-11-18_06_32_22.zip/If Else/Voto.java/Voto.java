/******************************************************************************

Escreva um programa que receba a idade de uma pessoa e informe sua situação em relação a votação:
Menor de 16 anos = Nâo pode votar
16 ou 17 ou acima de 70 = Voto facultativo
Entre 18 e 70 anos = Voto Obrigatório
*******************************************************************************/
public class Voto
{
	public static void main(String[] args) {
	    
int Idade = 27;	    // alterar esse bloco para saber os resultados 
int x = 16;  
int y = 17; 
int w = 70; 
	    
	    if (Idade < 16 )
{
		System.out.println("Não pode votar");
}
else if (Idade == x  || Idade == y || Idade > w)
{
		System.out.println("Voto facultativo");
	}
else 
{
    System.out.println ("Voto Obrigatório");
}
}
}
	    

