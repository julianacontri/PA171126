/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class combustivel
{
	public static void main(String[] args) 
	{
	    int distancia = 1000;
	    int consumo = 8;
	    int resultado;
	    
	    resultado = (distancia * consumo);
	    
		System.out.println("resultado combustivel" +resultado);
	}
}
