/// Loja de Eletrônicos
///Receba o valor de 8 produtos vendidos e encontre o mais caro.
///Dica de solução: Guarde o maior valor digitado.

import java.util.Scanner;


public class EletronicosFOR {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double maiorValor = 0; // Guarda o maior valor que for digitado

        System.out.println("--- Cadastro de Vendas ---");

        // vai rodar  exatamente 8 vezes (de 1 a 8)
        for (int i = 1; i <= 8; i++) {
            System.out.print("Digite o valor do " + i + "º produto: R$ ");
            double valorAtual = scanner.nextDouble();

            // quando digitar o valor, vai atualizar
            if (valorAtual > maiorValor) {
                maiorValor = valorAtual;
            }
        }

        // quando sair do loop vai mostrar o resultado
        System.out.println("\n---------------------------------");
        System.out.printf("O produto mais caro vendido custou: R$ %.2f%n", maiorValor);
        System.out.println("---------------------------------");

        scanner.close();
    }
}
