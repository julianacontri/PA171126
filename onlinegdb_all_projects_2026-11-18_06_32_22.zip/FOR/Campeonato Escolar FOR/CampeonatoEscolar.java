import java.util.Scanner;

public class CampeonatoEscolar {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Inicializa as variáveis com os valores extremos possíveis
        int maiorPontuacao = Integer.MIN_VALUE;
        int menorPontuacao = Integer.MAX_VALUE;
        int somaPontuacao = 0;

        System.out.println("--- Campeonato Escolar ---");

        // Laço FOR para repetir a leitura 10 vezes
        for (int i = 1; i <= 10; i++) {
            System.out.print("Digite a pontuação da equipe " + i + ": ");
            int pontuacao = scanner.nextInt();

            // Soma a pontuação para calcular a média depois
            somaPontuacao += pontuacao;

            // Verifica se é a maior pontuação até agora
            if (pontuacao > maiorPontuacao) {
                maiorPontuacao = pontuacao;
            }

            // Verifica se é a menor pontuação até agora
            if (pontuacao < menorPontuacao) {
                menorPontuacao = pontuacao;
            }
        }

        // Calcula a média das pontuações
        double media = (double) somaPontuacao / 10;

        // Exibe os resultados
        System.out.println("\n--- Resultado Final ---");
        System.out.println("Maior pontuação: " + maiorPontuacao);
        System.out.println("Menor pontuação: " + menorPontuacao);
        System.out.println("Média de pontuação do campeonato: " + media);

        scanner.close();
    }
}
