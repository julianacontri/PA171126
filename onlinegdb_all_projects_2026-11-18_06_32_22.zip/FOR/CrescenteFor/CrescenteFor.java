///Crescente
///Crie um programa que exiba os números de 1 até 20 utilizando a estrutura for.
///Dica de solução: Utilize um contador iniciando em 1 e incrementando até 20.
 
 import java.util.Scanner;
 
 public class CrescenteFor {
    public static void main(String[] args) {
        // O laço começa em 1, vai até 20 (enquanto i <= 20) e aumenta de 1 em 1 (i++)
        for (int i = 1; i <= 20; i++) {
            System.out.println(i);
        }
    }
}
