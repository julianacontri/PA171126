///Controle de Temperatura
///Receba temperaturas de 7 dias e encontre a maior e a menor.
///Dica de solução: Compare cada valor informado.

import java.util.Scanner;
import java.util.Scanner;

public class ControledeTemperatura {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Declaração das variáveis para armazenar a maior e a menor temperatura
        double maiorTemp = 0;
        double menorTemp = 0;

        System.out.println("--- Controle de Temperatura (7 dias) ---");

        // Loop 'for' para repetir a leitura durante 7 dias
        for (int i = 1; i <= 7; i++) {
            System.out.print("Digite a temperatura do dia " + i + ": ");
            double tempAtual = scanner.nextDouble();

            // Na primeira repetição (dia 1), a temperatura atual é tanto a maior quanto a menor
            if (i == 1) {
                maiorTemp = tempAtual;
                menorTemp = tempAtual;
            } else {
                // Comparações para os dias seguintes (dias 2 a 7)
                if (tempAtual > maiorTemp) {
                    maiorTemp = tempAtual; // Atualiza a maior
                }
                if (tempAtual < menorTemp) {
                    menorTemp = tempAtual; // Atualiza a menor
                }
            }
        }

        // Exibe os resultados finais
        System.out.println("\n--- Resultados ---");
        System.out.println("A maior temperatura registrada foi: " + maiorTemp + "°C");
        System.out.println("A menor temperatura registrada foi: " + menorTemp + "°C");

        scanner.close();
    }
}
