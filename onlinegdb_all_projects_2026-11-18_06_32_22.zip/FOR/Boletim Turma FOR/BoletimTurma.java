/// Boletim da Turma
//Receba as notas de 15 alunos e apresente média, aprovados e reprovados.
//Dica de solução: Combine contadores e acumuladores.

import java.util.Scanner;

public class BoletimTurma {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Constante para o número de alunos
        final int TOTAL_ALUNOS = 15;
        
        // Acumulador
        double somaNotas = 0;
        
        // Contadores
        int aprovados = 0;
        int reprovados = 0;
        
        System.out.println("--- Boletim da Turma ---");
        
        // Loop FOR para receber as notas dos 15 alunos
        for (int i = 1; i <= TOTAL_ALUNOS; i++) {
            System.out.print("Digite a nota do aluno " + i + ": ");
            double nota = scanner.nextDouble();
            
            // Acumula a nota para o cálculo da média posterior
            somaNotas += nota;
            
            // Verifica a situação do aluno (critério de aprovação: nota maior ou igual a 6.0)
            if (nota >= 6.0) {
                aprovados++;
            } else {
                reprovados++;
            }
        }
        
        // Cálculo da média da turma
        double mediaTurma = somaNotas / TOTAL_ALUNOS;
        
        // Exibição dos resultados
        System.out.println("\n--- Resumo do Boletim ---");
        System.out.printf("Média da turma: %.2f\n", mediaTurma);
        System.out.println("Quantidade de alunos aprovados: " + aprovados);
        System.out.println("Quantidade de alunos reprovados: " + reprovados);
        
        scanner.close();
    }
}
