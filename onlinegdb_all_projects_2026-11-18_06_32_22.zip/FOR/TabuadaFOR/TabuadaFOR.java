///Solicite um número ao usuário e exiba a tabuada de 1 até 10 utilizando while.
///Dica de solução: Use um contador de 1 a 10.

import java.util.Scanner;

public class TabuadaFOR {
    public static void main(String[] args) 
    {
        Scanner entrada = new Scanner(System.in);
        int conta = 0;  
        System.out.println("Digite um número para ver a sua tabuada: ");
        
        int numero = entrada.nextInt();
        
            System.out.println("Tabuada do: "+numero);
            
            // Aqui vamos inserir a estrutura de repetição, quantas vezes o código vai ser executado. 
            //No exemplo a estrutura tem que rodar 10 vezes
            
            for (int i =0; i<=10;i ++)
            {
            conta = numero * i; 
            System.out.println(numero+" x" +i + "="+ conta );
            }
        }
    }

