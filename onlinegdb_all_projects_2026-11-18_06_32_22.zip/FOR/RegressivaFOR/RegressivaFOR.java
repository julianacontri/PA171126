///Contagem Regressiva
///Desenvolva um programa que exiba os números de 20 até 1.
///Dica de solução: Utilize o contador iniciando em 20 e decrementando até 1.
/// for (inicializaçãp;condição;incremento/decremento)

import java.util.Scanner;

public class RegressivaFOR {
    public static void main(String[] args) {
        // O loop começa em 20, continua enquanto i for maior ou igual a 1, e diminui 1 a cada volta
        for (int i = 20; i >= 1; i--) {
            System.out.println(i);
        }
    }
}
