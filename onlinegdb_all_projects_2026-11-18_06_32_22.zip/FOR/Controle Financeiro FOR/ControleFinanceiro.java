///Controle Financeiro
//Receba 12 despesas mensais e calcule total e média.
//Dica de solução: Simule um controle financeiro pessoal.



import java.util.Scanner;

public class ControleFinanceiro {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        double totalDespesas = 0;

        System.out.println("--- SIMULADOR DE CONTROLE FINANCEIRO ---");
        System.out.println("Por favor, insira as despesas dos 12 meses:\n");

        // Loop 'for' que roda exatamente 12 vezes (uma para cada mês)
        for (int mes = 1; mes <= 12; mes++) {
            System.out.print("Digite a despesa do mês " + mes + ": R$ ");
            double despesa = scanner.nextDouble();
            
            // Acumula o valor digitado no total
            totalDespesas += despesa;
        }

        // Calcula a média dividindo o total por 12
        double mediaMensal = totalDespesas / 12;

        // Exibe os resultados formatados
        System.out.println("\n----------------------------------------");
        System.out.printf("Total de despesas no ano: R$ %.2f%n", totalDespesas);
        System.out.printf("Média de despesa mensal:  R$ %.2f%n", mediaMensal);
        System.out.println("----------------------------------------");

        scanner.close();
    }
}
