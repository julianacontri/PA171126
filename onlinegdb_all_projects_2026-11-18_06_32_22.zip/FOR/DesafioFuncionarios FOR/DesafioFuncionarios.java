/// Desafio Funcionários FOR

import java.util.Scanner;

public class DesafioFuncionarios {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Variáveis para armazenar os dados de controle e estatísticas
        int totalFuncionarios = 10;
        double somaSalarios = 0;
        double maiorSalario = Double.MIN_VALUE; // Inicializa com o menor valor possível
        double menorSalario = Double.MAX_VALUE; // Inicializa com o maior valor possível

        // Laço FOR para cadastrar os 10 funcionários
        for (int i = 1; i <= totalFuncionarios; i++) {
            System.out.println("--- Cadastro do " + i + "º Funcionário ---");
            System.out.print("Nome: ");
            String nome = scanner.nextLine();

            System.out.print("Salário: R$ ");
            double salario = scanner.nextDouble();
            scanner.nextLine(); // Limpa o buffer do teclado após ler o double

            // Acumula o salário para a soma e média posterior
            somaSalarios += salario;

            // Verifica se é o maior salário informado
            if (salario > maiorSalario) {
                maiorSalario = salario;
            }

            // Verifica se é o menor salário informado
            if (salario < menorSalario) {
                menorSalario = salario;
            }
            System.out.println(); // Linha em branco para organizar o console
        }

        // Calcula a média salarial
        double mediaSalarial = somaSalarios / totalFuncionarios;

        // --- Apresentação dos Resultados Finais ---
        System.out.println("========== RESULTADO FINAL ==========");
        System.out.println("Quantidade de funcionários cadastrados: " + totalFuncionarios);
        System.out.printf("Soma dos salários: R$ %.2f%n", somaSalarios);
        System.out.printf("Média salarial: R$ %.2f%n", mediaSalarial);
        System.out.printf("Maior salário informado: R$ %.2f%n", maiorSalario);
        System.out.printf("Menor salário informado: R$ %.2f%n", menorSalario);
        System.out.println("=====================================");

        scanner.close();
    }
}

