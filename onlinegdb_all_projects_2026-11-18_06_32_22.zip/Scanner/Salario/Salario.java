/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Salario


{
	public static void main(String[] args) 
	{
	    int quantidadehoras= 1000;
	    int valorhora= 20;
	    int resultado;
	    
	    resultado =(quantidadehoras * valorhora);
		System.out.println("resultado Salario"  + resultado);
	}
}
