////Solicite 4 notas de um aluno e calcule a média.
///Dica de solução: Some as notas e divida pela quantidade.

import java.util.Scanner;

public class Média4Notas {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Solicita as 4 notas do aluno
        System.out.print("Digite a primeira nota: ");
        double nota1 = scanner.nextDouble();

        System.out.print("Digite a segunda nota: ");
        double nota2 = scanner.nextDouble();

        System.out.print("Digite a terceira nota: ");
        double nota3 = scanner.nextDouble();

        System.out.print("Digite a quarta nota: ");
        double nota4 = scanner.nextDouble();

        // Calcula a média
        double media = (nota1 + nota2 + nota3 + nota4) / 4;

        // Exibe a média formatada com duas casas decimais
        System.out.printf("A média do aluno é: %.2f%n", media);
        }
    }
}
