///Desenvolva um programa que exiba os números de 1 até 10 utilizando uma estrutura while.
///Dica de solução: Crie uma variável contador iniciando em 1 e incremente até chegar a 10

import java.util.Scanner;
public class ContagemRegressiva {
    public static void main (String [] args)
    {
        Scanner teclado = new Scanner (System.in);
        System.out.println ("Exiba os números de 1 a 10 em Contagem Regressiva");
        int resposta = teclado.nextInt();
        while (resposta <=10 && resposta >=1)
        {
            System.out.println(resposta);
            resposta = resposta -1;
        }
    }
}
