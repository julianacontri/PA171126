///////Programa em Java que mostra os números pares
/////Escreva um aplicativo em Java mostra todos os números pares de 1 até 100.

import java.util.Scanner;


public class Pares {
  public static void main(String[] args) {
      int numero = 1;
      
    System.out.println(" Pares de 1 a 100");
    
    while (numero <= 100) {
        if (numero % 2 ==0) {
            System.out.print (numero + " ");
        }
    numero ++;
    }  
  }
}