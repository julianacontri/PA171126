import java.util.Scanner;


public class Impares {
  public static void main(String[] args) {
      int numero = 1;
      
    System.out.println(" Impares de 1 a 100");
    
    while (numero <= 100) {
        if (numero % 2!=0) {
            System.out.print (numero + " ");
        }
    numero ++;
    }  
  }
}
