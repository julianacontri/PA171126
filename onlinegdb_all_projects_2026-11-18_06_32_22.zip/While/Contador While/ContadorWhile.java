import java.util.Scanner;


public class ContadorWhile {
  public static void main(String[] args) 
  {
    Scanner teclado = new Scanner (System.in);
   System.out.println("Coloque seu número favorito! Mas não exagere");
   int resposta = teclado.nextInt();
   
    while (resposta < 100) 
    {
      System.out.println(resposta);
      resposta = resposta+1;
    }  
    }
  }
