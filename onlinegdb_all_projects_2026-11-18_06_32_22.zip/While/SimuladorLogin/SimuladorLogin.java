////Solicite usuário e senha até que sejam informados admin e 1234.
///Dica de solução: Repita o login enquanto estiver incorreto.

import java.util.Scanner;

public class SimuladorLogin {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Variáveis para armazenar o que o usuário digitar
        String usuario;
        String senha;
        
        // Variável de controle do laço
        boolean loginIncorreto = true;

        // Repete o login enquanto estiver incorreto
        while (loginIncorreto) {
            System.out.print("Digite o usuário: ");
            usuario = scanner.nextLine();

            System.out.print("Digite a senha: ");
            senha = scanner.nextLine();

            // O 'if' verifica se as duas credenciais estão corretas
            if (usuario.equals("admin") && senha.equals("1234")) {
                System.out.println("Acesso concedido! Bem-vindo.");
                loginIncorreto = false; // Altera para falso para encerrar o while
            } else {
                System.out.println("Usuário ou senha incorretos. Tente novamente.\n");
            }
        }

        scanner.close();
    }
}
