///Solicite um número ao usuário e exiba a tabuada de 1 até 10 utilizando while.
///Dica de solução: Use um contador de 1 a 10.

import java.util.Scanner;

public class Tabuada {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite um número para ver a sua tabuada: ");
        int numero = scanner.nextInt();

        // Uso do IF: Valida se o número é maior que zero
        if (numero > 0) {
            int contador = 1; // Contador sugerido na dica

            System.out.println("\nTabuada do " + numero + ":");
            
            // Uso do WHILE: Executa o bloco de 1 até 10
            while (contador <= 10) {
                int resultado = numero * contador;
                System.out.println(numero + " x " + contador + " = " + resultado);
                contador++; // Incrementa o contador para não gerar loop infinito
            }
        } else {
            System.out.println("Por favor, insira um número positivo maior que zero.");
        }

        scanner.close();
    }
}
