/// Desafio Final
///Desenvolva um sistema escolar que solicite nome e média de vários alunos. O cadastro deve ser encerrado quando for digitado FIM. Ao final informe quantidade de alunos, aprovados, reprovados e média geral da turma.


import java.util.Scanner;

public class DesafioWhile {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Variáveis de contagem e soma
        int totalAlunos = 0;
        int aprovados = 0;
        int reprovados = 0;
        double somaMedias = 0.0;

        System.out.println("--- Sistema de Cadastro Escolar ---");
        System.out.println("Digite 'FIM' no nome do aluno para encerrar.\n");

        while (true) {
            System.out.print("Digite o nome do aluno: ");
            String nome = scanner.nextLine();

            // Condição para encerrar o programa (ignora maiúsculas/minúsculas)
            if (nome.equalsIgnoreCase("FIM")) {
                break;
            }

            System.out.print("Digite a média do aluno (0 a 10): ");
            double media = scanner.nextDouble();
            scanner.nextLine(); // Limpa o buffer do teclado

            // Acumula os dados para o relatório final
            totalAlunos++;
            somaMedias += media;

            // Condição para verificar aprovação (Critério: Média igual ou maior que 7.0)
            if (media >= 7.0) {
                aprovados++;
                System.out.println("Situação: Aprovado\n");
            } else {
                reprovados++;
                System.out.println("Situação: Reprovado\n");
            }
        }

        // Exibição do relatório final
        System.out.println("\n--- RELATÓRIO FINAL DA TURMA ---");
        System.out.println("Quantidade total de alunos: " + totalAlunos);
        System.out.println("Alunos aprovados: " + aprovados);
        System.out.println("Alunos reprovados: " + reprovados);

        // Uso do if para evitar divisão por zero caso nenhum aluno seja cadastrado
        if (totalAlunos > 0) {
            double mediaGeral = somaMedias / totalAlunos;
            System.out.printf("Média geral da turma: %.2f\n", mediaGeral);
        } else {
            System.out.println("Média geral da turma: 0.00 (Nenhum aluno cadastrado)");
        }

        scanner.close();
    }
}
