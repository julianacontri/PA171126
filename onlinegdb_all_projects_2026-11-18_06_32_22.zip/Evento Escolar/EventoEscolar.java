/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
{
	public static void main(String[] args) 
	{
	    int participantes= 100;
	    int valoringresso= 80;
	    int resultado;
	    
	    resultado =(participantes * valoringresso);
		System.out.println("resultado EventoEscolar"  + resultado);
	}
