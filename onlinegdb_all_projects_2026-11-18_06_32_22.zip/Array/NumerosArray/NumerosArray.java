/******************************************************************************

Exercício 1 – Armazenando Números 

Crie um programa que declare um vetor capaz de armazenar 5 números inteiros. 
Solicite os valores e exiba todos os números armazenados. 

*******************************************************************************/


import java.util.Scanner;

public class NumerosArray {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite os valores: ");
        int numero = scanner.nextInt();

 int[] numeros = {10, 30, 60, 90, 120};

        // Laço 'for' percorrendo do índice 0 até o tamanho total do vetor (5)
        for (int i = 0; i < numeros.length; i++) {
            System.out.println("Valores: " + i + " | Valor armazenado: " + numeros[i]);
        }
    }
}

