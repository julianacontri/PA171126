/******************************************************************************

Exercício 3 – Soma dos Elementos 

Solicite 10 números inteiros, armazene-os em um vetor e apresente a soma total. 

Dica de solução: Utilize uma variável acumuladora. 
*******************************************************************************/
public class SomaArray {
  public static void main(String[] args) {
    int[] numbers = {1, 5, 10, 25,30,35,40,45,50,55,60};
    int sum = 0;

    // Loop through the array and add each element to sum
    for (int i = 0; i < numbers.length; i++) {
      sum += numbers[i];
    }

    System.out.println("The sum is: " + sum);
  }
}
