/******************************************************************************

Exercício 2 – Cadastro de Alunos 

Armazene os nomes de 5 alunos em um vetor e exiba a lista completa ao final. 

Dica de solução: Use um vetor String. 
*******************************************************************************/
public class AlunosArray {
  public static void main(String[] args) {
    String[] AlunosArray = {"André", "Anselmo", "Beatriz", "Diogo", "Enzo"};
    for (int i = 0; i < AlunosArray.length; i++) {
      System.out.println(AlunosArray[i]);
    }
  }
}
