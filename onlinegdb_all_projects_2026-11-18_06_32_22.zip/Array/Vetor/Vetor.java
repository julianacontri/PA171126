
public class Vetor {
    public static void main(String[] args) {
        // Declaração e inicialização direta do vetor com 5 valores inteiros
        int[] numeros = {20, 40, 60, 80, 65};

        // Laço 'for' percorrendo do índice 0 até o tamanho total do vetor (5)
        for (int i = 0; i < numeros.length; i++) {
            System.out.println("Índice: " + i + " | Valor armazenado: " + numeros[i]);
        }
    }
}