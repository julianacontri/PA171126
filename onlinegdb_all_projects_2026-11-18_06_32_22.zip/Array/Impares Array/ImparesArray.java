/******************************************************************************

Exercício 9 – Números Ímpares 

Solicite 10 números e exiba apenas os números ímpares. 

Dica de solução: Verifique o resto da divisão por 2. 
*******************************************************************************/
import java.util.Scanner;

public class ImparesArray {
  public static void main(String[] args) 
  {
    Scanner entrada = new Scanner(System.in);

        int numeros[] = new int[10];

        // Preenchendo o vetor
        for (int i = 0; i < 10; i++) {
            System.out.print("Digite o " + (i + 1) + "º número: ");
            numeros[i] = entrada.nextInt();
        }

        System.out.println("\nNúmeros armazenados no vetor:");

        // Exibindo os valores do vetor
        for (int i = 0; i < 10; i++) {
            System.out.println("Exibe impares " + i + ": " + numeros[i]);
        {
        if (numero % 2!=0) {
            System.out.print (numero + " ");
        }
    numero ++;
        }

        entrada.close();
    }

